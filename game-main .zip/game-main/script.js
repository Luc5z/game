function executeCommand(command) {
    const unama = document.querySelector('.unama');

    switch (command) {
      
        case 'flex-start':
            unama.style.justifyContent = 'flex-start';
            break;
        case 'flex-end':
            unama.style.justifyContent = 'flex-end';
            break;
        case 'center':
            unama.style.justifyContent = 'center';
            break;
        case 'space-between':
            unama.style.justifyContent = 'space-between';
            break;
        case 'space-around':
            unama.style.justifyContent = 'space-around';
            break;
        case 'space-evenly':
            unama.style.justifyContent = 'space-evenly';
            break;
     
        case 'flex-start-align-start':
            unama.style.alignItems = 'flex-start';
            break;
        case 'flex-end-align-end':
            unama.style.alignItems = 'flex-end';
            break;
        case 'center-align-center':
            unama.style.alignItems = 'center';
            break;
        case 'baseline':
            unama.style.alignItems = 'baseline';
            break;
        case 'stretch':
            unama.style.alignItems = 'stretch';
            break;
        default:
            break;
    }
   
    checkObjective();
}

function checkObjective() {
    const alvaro = document.getElementById('alvaro');
    const objetivo = document.querySelector('.objetivo');

    const alvaroRect = alvaro.getBoundingClientRect();
    const objetivoRect = objetivo.getBoundingClientRect();

    
    if (alvaroRect.left >= objetivoRect.left && 
        alvaroRect.right <= objetivoRect.right && 
        alvaroRect.top >= objetivoRect.top && 
        alvaroRect.bottom <= objetivoRect.bottom) {
       
        alert("Parabéns! Você alcançou o objetivo!");
    }
}
