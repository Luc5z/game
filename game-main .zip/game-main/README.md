# Projeto de Desenvolvimento de Jogo em JavaScript, CSS e HTML

Bem-vindo ao repositório do projeto de desenvolvimento de jogo! Este é um trabalho colaborativo envolvendo 8 desenvolvedores talentosos.

## Desenvolvedores

### 1. João Dias
- **Função:** 
- **Resumo:** 
- **Habilidades:** 
- **GitHub:** [nick](https://github.com/)

### 2. Heitor Amaral
- **Função:** 
- **Resumo:** 
- **Habilidades:** 
- **GitHub:** [nick](https://github.com/)

### 3. Rey Hall
- **Função:** Trilha sonora
- **Resumo:** Adicionar uma ou mais trilhas sonoras no jogo
- **Habilidades:** Organizado
- **GitHub:** [nick](https://github.com/)

### 4. Gustavo Rocha
- **Função:** pixel-art
- **Resumo:** fazer o design do personagem principal e ícones de objetos junto com algumas animações 
- **Habilidades:** MYSQL, css, html, aseprite
- **GitHub:** [nick](https://github.com/)

### 5. David Gabriel
- **Função:** Programar o sistema do Jogo de movimentos
- **Resumo:** sistema de locomoção e conclusão de tarefas
- **Habilidades:** JS, Html, css, MYSQL, Python 
- **GitHub:** [davidxxgabriel](https://github.com/davidxxgabriel)

### 6. Felipe Pará
- **Função:** 
- **Resumo:** 
- **Habilidades:** 
- **GitHub:** [nick](https://github.com/)

### 7. Daniel Vilhena
- **Função:** 
- **Resumo:** 
- **Habilidades:** 
- **GitHub:** [nick](https://github.com/)

### 8. Dival Lucas
- **Função:** 
- **Resumo:** 
- **Habilidades:** 
- **GitHub:** [nick](https://github.com/)

